void c3a(int retval) // choose amongst alternative actions
{


/*** add character before ip                ***/
/*** delete character under ip              ***/
/*** overwrite character under ip           ***/

/*** insert: toggle insert overwrite        ***/
/*** home: set ip to home position          ***/
/*** end: set ip to end position            ***/
/*** enter: split line                      ***/
/*** ctrl-k: delete line                    ***/
/*** back space: decrement ip               ***/

}
