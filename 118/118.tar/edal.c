int edal(int retval, int fetch)
{
  char c = retval;         // retrieve a 1 byte character 
                           // from a 4 byte integer

  int test = (retval > 31 && retval < 127); // true for printable character

  if (test)                                {chin(c,fetch); return 0;}     
  if (retval == BACKSPACE  & cord.ix != 0) {cord.ix-- ;    return 0;}
  if (retval == ARROW_LEFT & cord.ix != 0) {cord.ix-- ;    return 0;}
  if (retval == ARROW_RIGHT)               {cord.ix++ ;    return 0;}
  if (retval == ARROW_UP   & cord.iy != 0) {cord.iy-- ;    return 0;}
  if (retval == ARROW_DOWN & cord.iy < global.lastline) 
                                           {cord.iy++ ;    return 0;}
  if (retval == ENTER)                     {enter();       return 0;}
 
  return 0;

}

