#include <fcntl.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

int main (int argc, char* argv[]) {  

   char* filename = argv[1];
   char* outline = "every day is a new day";
   char  newline = 10;
   int ignore;

/* unlink the file name */

   ignore = unlink(filename);

/* Open the filename for writing.  
   If it exists, append to it;
   otherwise, create a new file.  */

   int fd = open (filename, O_WRONLY | O_CREAT | O_APPEND , 0666);

   size_t length = strlen (outline);
   write (fd, outline, length);
   write (fd, &newline, 1);

   close (fd); return 0; 
   }
