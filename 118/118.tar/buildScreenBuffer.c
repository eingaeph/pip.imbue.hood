void buildScreenBuffer(int star, int stop)
{
}


