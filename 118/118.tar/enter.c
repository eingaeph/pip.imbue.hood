void enter(void)
{
      // state: ix text insertion point coordinate
  int ix = cord.ix;    
      // state: iy text insertion point coordinate
  int iy = cord.iy;
      // state: ENTER (implicit on entry)
      // state: text[iy].size
  int leng = text[iy].size; 
      // state: lastline: number of lines in text at entryi
  int lastline = global.lastline;

      // calculate: iy_firs : y coordinate first line
  int iy_firs = iy;
      // calculate: iy_seco : y coordinate second line 
  int iy_seco = iy++;
      // calculate: length of new line firs
  int lena = ix;
      // calculate: length of new line seco
  int lenb = text[iy].size - lena;

      // allocate new string (line) firs
      char *firs = malloc(lena*sizeof(char));
      // allocate new string (line) seco
      char *seco = malloc(lenb*sizeof(char));

      // populate firs newline
  char *chng = firs;
  char *orig = text[iy].row; 
  int no; for (no = 0 ; no < lena; no++)
    {*chng = *orig; chng++; orig++;}

      // populate seco newline
  chng = seco;
  for (no = lena ; no < lena + lenb; no++)
    {*chng = *orig; chng++; orig++;}

      // malloc slot *new with space for extra line
      // fill new
      // realloc text with space for extra line
      // text = new
      // global.lastline ++;
      // cord.ix++;

  write(STDOUT_FILENO,firs,lena);
  write(STDOUT_FILENO,"\n\r",2);
  write(STDOUT_FILENO,seco,lenb);
  write(STDOUT_FILENO,"\n\r",2);

  free(firs);
  free(seco);
      // free(new)
}
