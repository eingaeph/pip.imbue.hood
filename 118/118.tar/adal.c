
void adal(void)    // add a line
{
      // state: ix text insertion point coordinate
      // state: iy text insertion point coordinate
      // state: ENTER
      // state: iy == iymax
      // state: lastline

      // action: malloc new line firs
      // action: malloc new line seco
      // populate new line firs
      // populate new line seco
   
      // calculate: iy_firs
      // calculate: iy_seco
      
      // malloc new with space for an extra line 
      // populate new

      // free text
      // malloc text with space for extra line
 
    slot *new  = (slot *)malloc(10*sizeof(slot));
    slot *old  = (slot *)malloc(10*sizeof(slot));

    int j;

    slot newline;
    char *ptr = "Hello world!";
    newline.row = ptr;
    newline.size = strlen(ptr);

    for (j = 0; j < 10; j++) 
      {if (j != 3) {new[j] = text[j];}
       else        {new[j] = newline;}
      }
}

