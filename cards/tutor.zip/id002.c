#! /usr/bin/tcc -run

// #ikj read arguments using unistd.h 

#include <unistd.h>
#include <string.h> // strlen

int main (int argc, char * argv[])
{
  const char msg[] = "Hello World!";
  write(STDOUT_FILENO, msg, sizeof(msg)-1);
  write(STDOUT_FILENO, "\n",1);

  write(STDOUT_FILENO, "from exe = ",11);
  write(STDOUT_FILENO, argv[0],strlen(argv[0]));
  write(STDOUT_FILENO,"\n",1);
  return 0;
}

