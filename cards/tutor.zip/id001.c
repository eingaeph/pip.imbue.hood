***************************************************************
#ikj hello world using write
***************************************************************

#include <unistd.h>

int
main (void)
{
  const char msg[] = "Hello World!";
  write(STDOUT_FILENO, msg, sizeof(msg)-1);

  return 0;
}

