// replay.c test a library against a keystroke stream
#include "../libk.h"

// replay.c returns retval identical readKey.c 
// after a keystroke stream 
// for testing purposes 

// prata page 515, nocalls has file scope, internal linkage
// nocalls is defined outside of all functions, with keyword static 
// nocalls is private its (current) translation unit
// by standard all static file scope variables initialize to zero so presumably
// the initialization of nocalls is not needed 

static int nocalls = 0;

int replay(void)
{

// call waiter for a pause before returning 

// int iw = 4234567; waiter(iw); // iw = 1234567;

 int store[200]; int retval;

// local variable store contains command test sequence
 
 
 int j = 1; char c;
            store[j] = ARROW_DOWN; j++;       // cursor at 01 screen col  = 02
            store[j] = PAGE_DOWN;  j++;       // cursor at 01 screen col  = 24
            store[j] = CTRL_Q;     j++;       // end
            store[j] = PAGE_DOWN;  j++;
            store[j] = PAGE_DOWN;  j++;
            store[j] = PAGE_DOWN;  j++;
            store[j] = END_KEY;    j++;
 c = 'a';   store[j] = c;          j++;  
 c = 'b';   store[j] = c;          j++;
            store[j] = ARROW_DOWN; j++;
 c = 'c';   store[j] = c;          j++;
 c = 'd';   store[j] = c;          j++;
            store[j] = ARROW_DOWN; j++;

            store[j] = CTRL_Q;     j++;

 nocalls ++;

 if (nocalls < j) retval = store[nocalls];
 else die("quitting after logic error in replay.c");

 return retval;

}
