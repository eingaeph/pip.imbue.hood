

int main(int argc, char** argv)
{

  init(argc, argv);

  while (1) 

   {
    int retval = ReadKey();

    cord.iy  = 4;

    edal(retval, cord.iy);

//    window(0,79,0,6);
   }

  return 0; // this statement is never reached
}
