#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>

int
main (void)
{

  int fd;


  if ( (fd = open("last.c", O_RDONLY) ) == -1 )
  {
     /* Error: can't open file */ 
     exit(43);
  }

  printf("file id: %i\n", fd);

  if (fd != -1) close(fd);

  return 31;
}

