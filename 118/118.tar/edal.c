int edal(int retval, int fetch)
{
  char c = retval;         // retrieve a 1 byte character 
                           // from a 4 byte integer

  int fpt = iovars.fptra;
  int insertionPoint = cord.ix; 

  if (retval == BACKSPACE  & cord.ix != 0) {cord.ix-- ; return 0;}
  if (retval == ARROW_LEFT & cord.ix != 0) {cord.ix-- ; return 0;}
  if (retval == ARROW_RIGHT)               {cord.ix++ ; return 0;}
  if (retval == ENTER)                     {enter();    return 0;}

  int test = (c > 31 && c < 127); // true for printable character
  if (!test) return 0;
 
  write(fpt, ClearScreen,strlen(ClearScreen));

  int limit = text[fetch].size + 1 ; 
  char *new = malloc((limit)*sizeof(char));
  char *chng = new;
  char *orig = text[fetch].row;

  int no; 
  for (no = 0 ; no < limit; no++)
    {
     if (no != cord.ix)  {*chng = *orig; chng++; orig++;}
     else                {*chng = c; chng++;}
    }

  free(text[fetch].row); 
  text[fetch].row = new; text[fetch].size = limit; cord.ix++;

  write(fpt,text[fetch].row,text[fetch].size); write(fpt,"\n\r",2);

  return 0;

}

