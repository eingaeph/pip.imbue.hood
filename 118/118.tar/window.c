void window(int xmin, int xmax, int ymin, int ymax)
{
    int y;
    for (y = ymin; y < ymax + 1; y++) 
  {
    char *s = xmin + text[y].row; 

    int no;
    for ( no = 0; no + xmin < xmax + 1; no++)     
    {
    if (no+1>text[y].size) {break;}; 
    if (*s == '\n')        {break;};
    write(STDOUT_FILENO,s,1); s++;
    }
    write(STDOUT_FILENO,"\n\r",2);
  }
}
