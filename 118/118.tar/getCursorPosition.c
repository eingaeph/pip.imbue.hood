int getCursorPosition(int *rows, int *cols) 
{
}

