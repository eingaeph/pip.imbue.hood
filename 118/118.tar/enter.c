void enter(void)
{
  int ix = cord.ix;    //text x insertion point
  int iy = cord.iy;    //text y insertion point
  int leng = text[iy].size; 
  int lastline = global.lastline; // number of rows in text
  int iy_firs = iy;    // y coordinate first modified row 
  int iy_seco = iy+1;  // y coordinate second modified row
  int lena = ix; // lenth of newline firs
  int lenb = text[iy].size - lena; //length of newline seco

  char *firs = malloc(lena*sizeof(char)); //malloc string firs
  char *seco = malloc(lenb*sizeof(char)); //malloc string seco

  char *chng = firs; // populate firs length lena 
  char *orig = text[iy].row; 
  int no; for (no = 0 ; no < lena; no++)
    {*chng = *orig; chng++; orig++;}

  chng = seco;       // populate seco length lenb
  for (no = lena ; no < lena + lenb; no++)
    {*chng = *orig; chng++; orig++;}

//malloc aray of slots new with space for extra line

  slot *new  = malloc((lastline+1)*sizeof(slot));

  slot firsline;
  firsline.row = malloc(lena*sizeof(char)); 
  memcpy(firsline.row, firs, lena);
  firsline.size = lena;

  slot secoline; 
  secoline.row = malloc(lenb*sizeof(char));
  memcpy(secoline.row, seco, lenb);
  secoline.size = lenb;
                       
  int j; int k = 0;
  for (j = 0; j < lastline; j++)  //build array of slots new
    {
     if (j != iy) { new[k] = text[j];  k++; }
     else         { new[k] = firsline; k++;
                    new[k] = secoline; k++; }
    }

  global.lastline ++; lastline = global.lastline; 
  free(text[iy].row);
  cord.ix = 0; cord.iy++;

  text = realloc(text,lastline*sizeof(slot));
  for (j = 0; j < lastline; j++) text[j] = new[j];

  free(firs); free(seco);
  free(new);
 
}
